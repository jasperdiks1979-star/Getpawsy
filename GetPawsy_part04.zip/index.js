// Production entrypoint - delegates to server.js
require('./server.js');
